package com.example.data.model

// One house record for one day. The id is the Firestore document ID, e.g. "2026-10-24_G-12".
data class CollectionRecord(
    val id: String = "",
    val houseType: String,        // "B", "C", "D", "E", "F", "G", "H"
    val houseNumber: String,      // e.g. "1", "12", "45-A"
    val isSegregated: Boolean,    // true = segregated, false = mixed
    val timestamp: Long = System.currentTimeMillis(),
    val dateString: String,       // "yyyy-MM-dd"
    val notes: String = ""
) {
    val fullAddress: String
        get() = "$houseType-$houseNumber"
}

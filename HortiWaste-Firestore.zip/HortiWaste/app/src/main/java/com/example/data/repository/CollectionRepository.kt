package com.example.data.repository

import com.example.data.model.CollectionRecord
import com.example.data.model.ColonyOverview
import com.example.data.model.DailySummary
import com.example.data.model.HouseTypeStat
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Reads and writes house records in Firestore.
 *
 * Offline behaviour: Firestore keeps writes on the phone when there is no internet
 * and uploads them automatically when the connection returns. The writes below do
 * not wait for the server, so the app never blocks on a slow or missing connection.
 *
 * Only the last 30 days are loaded. This keeps reads within Firestore's free daily limit.
 */
class CollectionRepository(
    private val db: FirebaseFirestore,
    scope: CoroutineScope
) {
    private val records = db.collection("records")

    // One live listener for the last 30 days. All screens derive their data from this.
    private val recent: StateFlow<List<CollectionRecord>> =
        recordsSince(daysAgoKey(29)).stateIn(scope, SharingStarted.Eagerly, emptyList())

    private fun recordsSince(startKey: String): Flow<List<CollectionRecord>> = callbackFlow {
        val registration = records
            .whereGreaterThanOrEqualTo("dateString", startKey)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null) {
                    trySend(snapshot.documents.mapNotNull { it.toRecord() })
                }
            }
        awaitClose { registration.remove() }
    }

    val allDates: Flow<List<String>> = recent.map { list ->
        list.map { it.dateString }.distinct().sortedDescending()
    }

    fun getRecordsForDate(date: String): Flow<List<CollectionRecord>> = recent.map { list ->
        list.filter { it.dateString == date }.sortedByDescending { it.timestamp }
    }

    fun searchRecords(query: String): Flow<List<CollectionRecord>> = recent.map { list ->
        val q = query.trim()
        list.filter {
            it.fullAddress.contains(q, ignoreCase = true) || it.houseNumber.contains(q, ignoreCase = true)
        }.sortedByDescending { it.timestamp }.take(100)
    }

    // Writes the record to Firestore. Re-submitting the same house on the same day replaces it.
    suspend fun saveRecord(
        houseType: String,
        houseNumber: String,
        isSegregated: Boolean,
        dateString: String,
        notes: String = ""
    ): CollectionRecord {
        val cleanType = houseType.trim().uppercase()
        val cleanNumber = houseNumber.trim()
        val record = CollectionRecord(
            id = documentId(dateString, cleanType, cleanNumber),
            houseType = cleanType,
            houseNumber = cleanNumber,
            isSegregated = isSegregated,
            timestamp = System.currentTimeMillis(),
            dateString = dateString,
            notes = notes
        )
        records.document(record.id).set(record.toMap())
        return record
    }

    suspend fun toggleSegregation(record: CollectionRecord) {
        records.document(record.id).update(
            mapOf(
                "isSegregated" to !record.isSegregated,
                "timestamp" to System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteRecord(record: CollectionRecord) {
        records.document(record.id).delete()
    }

    fun getDailySummaryFlow(date: String): Flow<DailySummary> = recent.map { list ->
        val day = list.filter { it.dateString == date }
        val segregated = day.count { it.isSegregated }
        DailySummary(
            dateString = date,
            totalHouses = day.size,
            segregatedCount = segregated,
            mixedCount = day.size - segregated
        )
    }

    fun getAllDailySummaries(): Flow<List<DailySummary>> = recent.map { list ->
        list.groupBy { it.dateString }
            .map { (date, day) ->
                val segregated = day.count { it.isSegregated }
                DailySummary(
                    dateString = date,
                    totalHouses = day.size,
                    segregatedCount = segregated,
                    mixedCount = day.size - segregated
                )
            }
            .sortedBy { it.dateString }
    }

    fun getColonyOverviewFlow(date: String): Flow<ColonyOverview> = recent.map { all ->
        val list = all.filter { it.dateString == date }
        val segregated = list.count { it.isSegregated }
        val supportedTypes = listOf("B", "C", "D", "E", "F", "G", "H")

        val typeStats = supportedTypes.map { type ->
            val typeRecords = list.filter { it.houseType.equals(type, ignoreCase = true) }
            val typeSegregated = typeRecords.count { it.isSegregated }
            HouseTypeStat(
                houseType = type,
                totalHouses = typeRecords.size,
                segregatedCount = typeSegregated,
                mixedCount = typeRecords.size - typeSegregated
            )
        }

        ColonyOverview(
            dateString = date,
            totalHouses = list.size,
            segregatedCount = segregated,
            mixedCount = list.size - segregated,
            typeStats = typeStats,
            records = list.sortedByDescending { it.timestamp }
        )
    }

    // ---------- helpers ----------

    // One document per house per day. "/" is not allowed in Firestore IDs, so it is replaced.
    private fun documentId(date: String, type: String, number: String): String =
        "${date}_${type}-${number}".replace("/", "-")

    private fun CollectionRecord.toMap(): Map<String, Any> = mapOf(
        "houseType" to houseType,
        "houseNumber" to houseNumber,
        "isSegregated" to isSegregated,
        "timestamp" to timestamp,
        "dateString" to dateString,
        "notes" to notes
    )

    private fun DocumentSnapshot.toRecord(): CollectionRecord? {
        val type = getString("houseType") ?: return null
        return CollectionRecord(
            id = id,
            houseType = type,
            houseNumber = getString("houseNumber") ?: "",
            isSegregated = getBoolean("isSegregated") ?: false,
            timestamp = getLong("timestamp") ?: 0L,
            dateString = getString("dateString") ?: "",
            notes = getString("notes") ?: ""
        )
    }

    private fun daysAgoKey(days: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -days)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }
}
